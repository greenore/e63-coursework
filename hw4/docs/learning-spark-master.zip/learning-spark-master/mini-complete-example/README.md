Mini Examples for Spark
===============
This directory contains a complete stand alone example with both Maven and SBT build tools.
