package com.oreilly.learningsparkexamples.java;

import java.io.Serializable;

public class CallLog implements Serializable {
  public String callsign;
  public Double contactlat;
  public Double contactlong;
  public Double mylat;
  public Double mylong;
}
